package com.showstar.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.Transformer.Listener
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.io.File

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private var videoUri: Uri? = null
    private var trimStartMs = 0L
    private var trimEndMs = Long.MIN_VALUE

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) loadVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<com.google.android.material.button.MaterialButton>(R.id.pickButton)
            .setOnClickListener { pickVideo.launch("video/*") }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.cutButton)
            .setOnClickListener { showTrimDialog() }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.speedButton)
            .setOnClickListener { showInfo("Speed", "Playback speed controls are ready for the editor UI. Export-speed processing can be added in the next build.") }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.musicButton)
            .setOnClickListener { showInfo("Music", "Choose your own audio track in the next editing module.") }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.textButton)
            .setOnClickListener { showTextDialog() }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.effectButton)
            .setOnClickListener { showInfo("Effects", "SHOW Star effects panel: Glitch, Shake, Zoom, Flash, Blur and Neon.") }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.filterButton)
            .setOnClickListener { showInfo("Filters", "SHOW Star filters: Film, Dream, Black & White, Neon and more.") }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.exportButton)
            .setOnClickListener { exportVideo() }
    }

    private fun loadVideo(uri: Uri) {
        videoUri = uri
        player?.release()
        player = ExoPlayer.Builder(this).build().also { p ->
            findViewById<androidx.media3.ui.PlayerView>(R.id.playerView).player = p
            p.setMediaItem(MediaItem.fromUri(uri))
            p.prepare()
            p.playWhenReady = false
        }
        findViewById<android.widget.TextView>(R.id.statusText).text =
            "Video loaded ✓  •  Add tools, then Export."
    }

    private fun showTrimDialog() {
        if (videoUri == null) {
            toast("আগে একটি ভিডিও যোগ করো")
            return
        }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 0, 40, 0)
        }
        val start = EditText(this).apply { hint = "Start (seconds)"; setText("0") }
        val end = EditText(this).apply { hint = "End (seconds, optional)" }
        box.addView(start); box.addView(end)
        MaterialAlertDialogBuilder(this)
            .setTitle("✂ Cut / Trim")
            .setView(box)
            .setPositiveButton("Apply") { _, _ ->
                trimStartMs = ((start.text.toString().toDoubleOrNull() ?: 0.0) * 1000).toLong().coerceAtLeast(0)
                val e = end.text.toString().toDoubleOrNull()
                trimEndMs = if (e == null) Long.MIN_VALUE else (e * 1000).toLong()
                findViewById<android.widget.TextView>(R.id.statusText).text =
                    "Trim: ${trimStartMs/1000}s → " + if (trimEndMs == Long.MIN_VALUE) "end" else "${trimEndMs/1000}s"
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showTextDialog() {
        val input = TextInputEditText(this).apply { hint = "Type your text" }
        MaterialAlertDialogBuilder(this)
            .setTitle("T Text")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text?.toString()?.trim().orEmpty()
                if (text.isNotEmpty()) toast("Text "$text" added to the editing plan.")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun exportVideo() {
        val uri = videoUri ?: run { toast("আগে একটি ভিডিও যোগ করো"); return }
        val outDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val output = File(outDir, "SHOW_Star_${System.currentTimeMillis()}.mp4")

        val mediaItemBuilder = MediaItem.Builder().setUri(uri)
        if (trimStartMs > 0 || trimEndMs != Long.MIN_VALUE) {
            val clip = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(trimStartMs)
                .apply { if (trimEndMs != Long.MIN_VALUE) setEndPositionMs(trimEndMs) }
                .build()
            mediaItemBuilder.setClippingConfiguration(clip)
        }

        val edited = EditedMediaItem.Builder(mediaItemBuilder.build()).build()
        val transformer = Transformer.Builder(this).addListener(object : Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult) {
                runOnUiThread {
                    findViewById<android.widget.TextView>(R.id.statusText).text = "Export complete ✓"
                    toast("SHOW Star video exported: ${output.name}")
                }
            }
            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: ExportException) {
                runOnUiThread { toast("Export failed: ${exportException.message}") }
            }
        }).build()

        findViewById<android.widget.TextView>(R.id.statusText).text = "Exporting… please wait"
        transformer.start(edited, output.absolutePath)
    }

    private fun showInfo(title: String, message: String) {
        MaterialAlertDialogBuilder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
